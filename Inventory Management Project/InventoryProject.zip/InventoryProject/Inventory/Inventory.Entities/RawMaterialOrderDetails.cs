﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.Entities
{
    public class RawMaterialOrderDetails
    {
        private int rawMaterialID;

        public int RawMaterialID
        {
            get { return RawMaterialID; }
            set { RawMaterialID = value; }
        }
        private int rawMaterialOrderQuantity;

        public int RawMaterialOrderQuantity
        {
            get { return rawMaterialOrderQuantity; }
            set { rawMaterialOrderQuantity = value; }
        }
        private double rawMaterialUnitPrice;

        public double RawMaterialUnitPrice
        {
            get { return rawMaterialUnitPrice; }
            set { rawMaterialUnitPrice = value; }
        }
        public double amount;

        public double Amount()
        {
            amount = RawMaterialOrderQuantity * RawMaterialOrderQuantity;
            return amount;
        }
        public RawMaterialOrderDetails()
        {
            rawMaterialID = 0;
            rawMaterialOrderQuantity = 0;
            rawMaterialUnitPrice = 0;
        }
    }
}
