﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.Entities
{
    public class RawMaterial
    {

            private int rawMaterialID;

            public int RawMaterialID
            {
                get { return RawMaterialID; }
                set { RawMaterialID = value; }
            }

            private string rawMaterialName;

            public string RawMaterialName
            {
                get { return RawMaterialName; }
                set { RawMaterialName = value; }
            }
            private int rawMaterialUnitPrice;

            public int RawMaterialUnitPrice
            {
                get { return rawMaterialUnitPrice; }
                set { rawMaterialUnitPrice = value; }
            }

            public RawMaterial()
            {
                RawMaterialID = 0;
                RawMaterialName = string.Empty;
            }
     }
}
