﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.Entities
{
    public class RawMaterialOrder
    {
        private int rawMaterialOrderID;
        public int RawMaterialOrderId
        {
            get { return rawMaterialOrderID; }
            set { rawMaterialOrderID = value; }
        }
        public RawMaterialOrder()
        {
            rawMaterialOrderID = 0;
        }
    }
}
