﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory
{
    class Program
    {
        public static void Main()
        {

        }
        public void PrintMenu()
        {
            Console.WriteLine("Menu:");
            Console.WriteLine("Raw materials");
            Console.WriteLine("1.Add Raw Material");
            Console.WriteLine("2.Update Raw Material");
            Console.WriteLine("3.Delete Raw Material");
            Console.WriteLine("4.Get All Raw Materials");
            Console.WriteLine("5.Search Raw Material by ID");
            Console.WriteLine("6.Search Raw Material by Name");
            Console.WriteLine("Orders");
            Console.WriteLine("7. Create Order");
            Console.WriteLine("8. Update Order");
            Console.WriteLine("9. Delete Order");
            Console.WriteLine("10. Search Order");
            Console.WriteLine("11. View All Orders");
            Console.WriteLine("11. View All Orders");
        }
    }
}
