﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory
{

        class Program
        {
            static void Main(string[] args)
            {
                int choice;
                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddRawMaterial();
                            break;
                        case 2:
                            UpdateRawMaterial();
                            break;
                        case 3:
                        DeleteRawMaterial(); 
                            break;
                        case 4:
                            ListAllRawMaterials();
                            break;
                        case 5:
                        SearchRawMaterialByID();
                        break;
                        case 6:
                        SearchRawMaterialByName();
                            return;
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                } while (choice != -1);
            }

            private static void DeleteRawMaterial()
            {
                try
                {
                    int deleteGuestID;
                    Console.WriteLine("Enter GuestID to Delete:");
                    deleteGuestID = Convert.ToInt32(Console.ReadLine());
                    Guest deleteGuest = GuestBL.SearchGuestBL(deleteGuestID);
                    if (deleteGuest != null)
                    {
                        bool guestdeleted = GuestBL.DeleteGuestBL(deleteGuestID);
                        if (guestdeleted)
                            Console.WriteLine("Guest Deleted");
                        else
                            Console.WriteLine("Guest not Deleted ");
                    }
                    else
                    {
                        Console.WriteLine("No Guest Details Available");
                    }


                }
                catch (GuestPhoneBookException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            private static void UpdateRawMaterial()
            {
                try
                {
                    int updateGuestID;
                    Console.WriteLine("Enter GuestID to Update Details:");
                    updateGuestID = Convert.ToInt32(Console.ReadLine());
                    Guest updatedGuest = GuestBL.SearchGuestBL(updateGuestID);
                    if (updatedGuest != null)
                    {
                        Console.WriteLine("Update Guest Name :");
                        updatedGuest.GuestName = Console.ReadLine();
                        Console.WriteLine("Update PhoneNumber :");
                        updatedGuest.GuestContactNumber = Console.ReadLine();
                        bool guestUpdated = GuestBL.UpdateGuestBL(updatedGuest);
                        if (guestUpdated)
                            Console.WriteLine("Guest Details Updated");
                        else
                            Console.WriteLine("Guest Details not Updated ");
                    }
                    else
                    {
                        Console.WriteLine("No Guest Details Available");
                    }


                }
                catch (GuestPhoneBookException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            private static void SearchRawMaterialByID()
            {
                try
                {
                    int searchGuestID;
                    Console.WriteLine("Enter GuestID to Search:");
                    searchGuestID = Convert.ToInt32(Console.ReadLine());
                    Guest searchGuest = GuestBL.SearchGuestBL(searchGuestID);
                    if (searchGuest != null)
                    {
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("GuestID\t\tName\t\tPhoneNumber");
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("{0}\t\t{1}\t\t{2}", searchGuest.GuestID, searchGuest.GuestName, searchGuest.GuestContactNumber);
                        Console.WriteLine("******************************************************************************");
                    }
                    else
                    {
                        Console.WriteLine("No Guest Details Available");
                    }

                }
                catch (GuestPhoneBookException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            private static void SearchRawMaterialByName()
            {
                try
                {
                    int searchGuestID;
                    Console.WriteLine("Enter GuestID to Search:");
                    searchGuestID = Convert.ToInt32(Console.ReadLine());
                    Guest searchGuest = GuestBL.SearchGuestBL(searchGuestID);
                    if (searchGuest != null)
                    {
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("GuestID\t\tName\t\tPhoneNumber");
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("{0}\t\t{1}\t\t{2}", searchGuest.GuestID, searchGuest.GuestName, searchGuest.GuestContactNumber);
                        Console.WriteLine("******************************************************************************");
                    }
                    else
                    {
                        Console.WriteLine("No Guest Details Available");
                    }

                }
                catch (GuestPhoneBookException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            private static void ListAllRawMaterials()
            {
                try
                {
                    List<Guest> guestList = GuestBL.GetAllGuestsBL();
                    if (guestList != null)
                    {
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("GuestID\t\tName\t\tPhoneNumber");
                        Console.WriteLine("******************************************************************************");
                        foreach (Guest guest in guestList)
                        {
                            Console.WriteLine("{0}\t\t{1}\t\t{2}", guest.GuestID, guest.GuestName, guest.GuestContactNumber);
                        }
                        Console.WriteLine("******************************************************************************");

                    }
                    else
                    {
                        Console.WriteLine("No Guest Details Available");
                    }
                }
                catch (GuestPhoneBookException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            private static void AddRawMaterial()
            {
                try
                {
                    RawMaterial newGuest = new RawMaterial();
                    Console.WriteLine("Enter GuestID :");
                    newGuest.GuestID = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Guest Name :");
                    newGuest.GuestName = Console.ReadLine();
                    Console.WriteLine("Enter PhoneNumber :");
                    newGuest.GuestContactNumber = Console.ReadLine();
                    bool guestAdded = GuestBL.AddGuestBL(newGuest);
                    if (guestAdded)
                        Console.WriteLine("Guest Added");
                    else
                        Console.WriteLine("Guest not Added");
                }
                catch (GuestPhoneBookException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

        private static void PrintMenu()
        {
            Console.WriteLine("Menu:");
            Console.WriteLine("----------------------");
            Console.WriteLine("1.Add Raw Material");
            Console.WriteLine("2.Update Raw Material");
            Console.WriteLine("3.Delete Raw Material");
            Console.WriteLine("4.Get All Raw Materials");
            Console.WriteLine("5.Search Raw Material by ID");
            Console.WriteLine("6.Search Raw Material by Name");
            Console.WriteLine("----------------------");
            Console.WriteLine("7. Create Order");
            Console.WriteLine("8. Update Order");
            Console.WriteLine("9. Delete Order");
            Console.WriteLine("10. Search Order by Order ID");
            Console.WriteLine("11. View All Orders");
        }
    }
    

       
    }
