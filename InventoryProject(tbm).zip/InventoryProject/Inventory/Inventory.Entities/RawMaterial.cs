﻿using System;
namespace Inventory.Entities
{
    public class RawMaterial
    {
        public int RawMaterialID { get; set; }
        public string RawMaterialName { get; set; }
        public int RawMaterialUnitPrice { get; set; }
    }
}
